from tests.testClass import TestConditionGenerator
import unittest
import coverage
from util.util import split_into_lemmas,split_into_tokens
def run_tests():
    suite = unittest.TestSuite()
    suite.addTest(TestConditionGenerator('testSentenseArray'))
    runner = unittest.TextTestRunner()

    cov = coverage.Coverage()
    cov.start()

    # .. call your code ..
    runner.run(suite)

    cov.stop()
    cov.save()
    cov.report()
    cov.xml_report()
    cov.html_report()


if __name__ == '__main__':
    run_tests()