cat > /opt/application/.env << EOL
[DEV]
CONSTANT_FOLDER = config
ROOT_PATH = $ROOT_PATH
EOL
