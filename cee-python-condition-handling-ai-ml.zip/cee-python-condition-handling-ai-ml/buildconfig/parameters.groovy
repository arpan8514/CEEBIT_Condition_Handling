env.build_version="0.0.16"
env.framework="python"
env.unitTest=true
env.deployment=true
// env.testCommand = "python runTest.py"
env.namespace="cee-dev"
env.ApplicationName="cee-condition-handling-ai-ml-python"
env.RepositoryName="618187721717.dkr.ecr.us-east-1.amazonaws.com/cee-dev"