import unittest
from dotenv import load_dotenv
load_dotenv()
import os
from index import api
from starlette.testclient import TestClient
client = TestClient(api)
import json
class TestConditionGenerator(unittest.TestCase):

    def setUp(self):
        f = open('tests/input_data.json')
        self.input = json.load(f)
        f = open('tests/output_data.json')
        self.output = json.load(f)

    def testSentenseArray(self):
        response = client.post("/generate-condition",json=self.input)
        #print(response.status_code)
        self.assertEqual(response.status_code, 200, "Should be 200")
        self.assertEqual(response.json()['condition_json'], self.output, "Should be like obj")



