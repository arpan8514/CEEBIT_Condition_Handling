python3 -m pip install install nltk
python3 -m nltk.downloader brown
python3 -m nltk.downloader wordnet
python3 -m pip install install textblob
python3 -m textblob.download_corpora
python3 -m pip install -r requirements.txt