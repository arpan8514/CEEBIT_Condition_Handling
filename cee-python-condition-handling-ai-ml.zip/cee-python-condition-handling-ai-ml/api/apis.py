import logging
import os
from fastapi import APIRouter, HTTPException, File, UploadFile
from pydentic_class.condition import ConditionInput, condition_responses, ConditionOutput
from service_classes.condition_generator import ConditionGenerator
#from util.util import paragrapToSentence
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html
from pydentic_class.setting import Settings
from fastapi.openapi.utils import get_openapi
logger = logging.getLogger(__name__)
router = APIRouter()



@router.get("/", include_in_schema=False)
async def get_swagger_documentation():
       setting=Settings()
       return get_swagger_ui_html(openapi_url=setting.openapi_url,title='Cognitive Condition Handling')

@router.get("/openapi.json", include_in_schema=False)
async def access_openapi():
    setting = Settings()
    openapi = get_openapi()
    openapi["servers"] = [{"url": setting.openapi_url}]
    return openapi


@router.post("/generate-condition",responses=condition_responses)
async def api_process_condition(items:ConditionInput):
    logger.info("api_process_condition start...")
    result = None
    try:
        req_json = items.dict()
        logger.info("Get all input sentences...")
        sentences = req_json['sentences']
        if(sentences==""):
            raise ValueError("All sentence should be in 'sentence' key and it cannot be empty.")

        cond_gen = ConditionGenerator()
        json_list = cond_gen.createConditionJson( sentences)
        result = {"condition_json":json_list,"status":"OK","status_code":200}
    except ValueError as err:
        logger.exception(err)
        raise HTTPException(status_code=422, detail={"status_code": 422, "message": str(err)})
    except Exception as err:
        logger.exception(err)
        raise HTTPException(status_code=500,detail={"status_code":500,"message":str(err)})
    finally:
        logger.info("api_process_condition End")
    return result

"""@router.post("/generate-condition-file",responses=condition_responses)
async def process_condition_file(story_file:UploadFile=File(...)):
    result = None
    try:
        contents = await story_file.read()
        sentences = paragrapToSentence(contents)

        cond_gen = ConditionGenerator()
        #json_list = createConditionJson(cond_gen, sentences)
        #result = json_list
    except Exception as err:
        raise HTTPException(status_code=500,detail=str(err))
    return result

@router.get("/generate_condition",response_model=ConditionOutput)
async def generate_condition():
    cond_gen = ConditionGenerator()
    fd = open("conditions.txt", "r")
    contents = fd.readlines()
    fd.close()
    condition_list = []
    for i in range(len(contents)):
        condition_list.append(contents[i].rstrip('\n'))

    json_list = cond_gen.createConditionJson(condition_list)

    return json_list"""


