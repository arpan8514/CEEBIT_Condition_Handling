import nltk
import re
import string
from nltk.corpus import wordnet
from nltk.tokenize import sent_tokenize
from textblob import TextBlob
from nltk import  pos_tag, ne_chunk
from nltk import  tree2conlltags
from nltk.stem.porter import PorterStemmer
def tokenize_sentence(sentence):
    # tokens = nltk.word_tokenize(sentence)
    sentence = re.sub("[|:!,*')@#%(&$?.^~{}]", "", sentence)
    sentence = sentence.strip(" ")
    # print("<======>",sentence)
    tokens = sentence.split(" ")
    tokens = list(filter(lambda token: token not in string.punctuation, tokens))
    return tokens

def conjunctionSpliter(input_sentence):
        prouction_rule_1 = nltk.RegexpParser(r""" 
                             phrase:
                             {<.*>+}    # chunking of everything
                             }<CC>+{    # chinking sequences of CC (coordinating conjunction)
                         """)

        taged_sentence = nltk.pos_tag(nltk.word_tokenize(input_sentence))

        result = prouction_rule_1.parse(taged_sentence)
        subtree_list = []

        for subtree in result.subtrees(filter=lambda t: t.label() == 'phrase'):
            subtree_list.append(" ".join([w[0] for w in subtree.leaves()]))
        return subtree_list


def getSynonims(word):
    syn = []
    for synset in wordnet.synsets(word):
        for lemma in synset.lemmas():
            syn.append(lemma.name())
    return syn

def getFlatString(tree,tree_label):
        leaves_list = []
        for subtree in tree.subtrees():
            if subtree.label() == tree_label:
                leaves_list = [leave[0]  for leave in subtree.leaves()]
        return " ".join(leaves_list)

def getTreeTags(tree):
        leaves_list = []
        for subtree in tree.subtrees():
           leaves_list = [leave[1]  for leave in subtree.leaves()]
        return leaves_list

def removeUnexpectedConjunction(sentence,unexpected_conjuction):
    for cc in unexpected_conjuction:
        if (cc in sentence):
            cc_new = re.sub(r"\bor\b", "", cc)
            sentence = sentence.replace(cc, cc_new)
    return sentence

def paragrapToSentence(file_content):
    file_content=str(file_content,'utf-8')
    #print(file_content)
    sent_text = sent_tokenize(file_content)
    i=1
    for t in sent_text:
        print(i,t)
    return sent_text

def split_into_lemmas(message):
    message = message.lower()
    words = TextBlob(message).words
    # for each word, take its "base form" = lemma
    return [word.lemma for word in words]
def stemmingSentence(action):
    porter_stemmer  = PorterStemmer()
    tokenization = tokenize_sentence(action)
    return [porter_stemmer.stem(word) for word in tokenization]
def findActionWord(type_list_dist,action):
    type_of_condition = ''
    action_2 = ''
    tfound = False
    for cond_type in type_list_dist:
        tfound = False
        for i in range(0, len(type_list_dist[cond_type])):
            word = r'\b' + type_list_dist[cond_type][i] + '\\b'
            # print(type_list_dist[cond_type][i])
            if (re.search(word, action.lower())):
                tfound = True
                action_2 = action.lower().replace(type_list_dist[cond_type][i], "").strip(" ")
                type_of_condition = cond_type
                break
        if (tfound): break
    return {"type_of_condition":type_of_condition,"action_2":action_2,"tfound":tfound}

def findActionWordFromToken(type_list_dist,action,tokens):
    type_of_condition = ''
    action_2 = ''
    tfound = False

    for cond_type in type_list_dist:

        for i in range(0, len(type_list_dist[cond_type])):
            k = 0
            word =  type_list_dist[cond_type][i]
            # print(type_list_dist[cond_type][i])
            for tk in tokens:
                if (word==tk):
                    tfound = True
                    action_token=action.split(" ")
                    action_token.pop(k)
                    action_2 = " ".join(action_token)
                    type_of_condition = cond_type
                    break
                k=k+1
        if (tfound): break
    print(action_2)
    return {"type_of_condition":type_of_condition,"action_2":action_2,"tfound":tfound}

def split_into_tokens(message):
    # message = unicode(message, 'utf8')  # convert bytes into proper unicode
    return TextBlob(message).words
def removeWordFromLast(matches_tags,last_not_allowed_tags):

    print(matches_tags)
    i = len(matches_tags)-1
    while i>=0:
        print("PREP WORD", i, matches_tags[i])
        if (matches_tags[i][1].strip(" ") in last_not_allowed_tags):
            print("DELETED WORD", i, matches_tags[i])
            matches_tags.pop(i)
        else:
            break

        i = i -1
    return " ".join([word[0] for word in matches_tags])
def findWordInSentence(list_of_word,sentence):
    found = False
    for word in list_of_word:
        if(word in sentence):
            found = True
            break
    return found

def createConditionStatement(conjunction_prash,condition_sentence,condition_extract_list):
    conjunction_queue = []
    condition_statement = ""
    conjunction_list = conjunction_prash["conjunction_list"]
    coupls_words = conjunction_prash["couple_word"]
    for cwords,conj in coupls_words.items():
        word_list = cwords.split("-")
        index1 = condition_sentence.find(word_list[0])
        if(index1>-1):
            index2 = condition_sentence.find(word_list[1],index1)
            condition_sentence = condition_sentence[:index2-1]+" "+conj+" "+condition_sentence[index2+len(word_list[1]):]
    sentence_word = condition_sentence.split(" ")
    for token in sentence_word:
        if(token in conjunction_list):
           conjunction_queue.append(token)

    for i in range(0,len(condition_extract_list)):
       condition_statement = condition_statement+" "+condition_extract_list[i]['id']
       if(i<len(conjunction_queue)):
           condition_statement = condition_statement+" "+conjunction_queue[i].upper()
    return condition_statement.strip()
def extractEachConditionSentence(condition_sentence):
    setences = conjunctionSpliter(condition_sentence)
    reformat_sentence = []
    i=0

    while i<len(setences):
        new_sentence = setences[i]
        if("between" in setences[i]):
            new_sentence = new_sentence+" and "+setences[i+1]
            i +=1

        reformat_sentence.append(new_sentence)
        i+=1

    return reformat_sentence
def getMatchWordFromList(index, sentence,operator_chunck_key_words,is_chunck=""):
        matched_word = ""
        found = False
        key_index = 'keywords'
        if(is_chunck == "subtree"):
            key_index = 'subtree_keywords'

        for word in operator_chunck_key_words[index][key_index]:
            if (word in sentence):
                found = True
                matched_word = word
                break
        return [found,matched_word]

def IOBTagging(input_sentence):
    taged_sentence = pos_tag(tokenize_sentence(input_sentence))
    tree = ne_chunk(taged_sentence)
    iob_tags = tree2conlltags(tree)
    name_list = []
    name = ""
    if(len(iob_tags)>1):
        prouction_rule_1 = nltk.RegexpParser(r""" 
                                     phrase:
                                     {<NNP|NN|CD><IN>?<NNP|NN>*}    # chunking of Name
                                    
                                 """)

        result = prouction_rule_1.parse(taged_sentence)


        for subtree in result.subtrees(filter=lambda t: t.label() == 'phrase'):
            name_list.append(" ".join([w[0] for w in subtree.leaves()]))
        name = " ".join(name_list)
    elif(len(iob_tags)==1):
        name = iob_tags[0][0]

    """name_list = []
    temp_list = []
    index = False
    nnp_found = False
    for i in range(0,len(iob_tags)):
        if iob_tags[i][1] == "NNP" and "B" in iob_tags[i][2]:
            name_list.append(iob_tags[i][0])
            index = True
            break
    for i in range(index,len(iob_tags)):
        temp_list.append(iob_tags[i][0])
        if (iob_tags[i][1] == "NNP"):
            nnp_found = True
            break
    if(nnp_found):
      name_list.extend(temp_list)"""

    #name_list = [el[0] for el in iob_tags if el[1] == "NNP" and el[2] != "O"]

    print(iob_tags)
    print(name)
    return name

def stringSearchIgnoreCase(word_list,sentence):
    re_output = None
    fword = ""
    for word in word_list:
        re_output = re.search(r"\b"+word+"\\b", sentence, re.IGNORECASE)
        if(re_output):
            fword = word
            break
    return {"re_output":re_output,"cond_word":fword}