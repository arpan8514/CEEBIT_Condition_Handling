#------------------------------------------------------------------------------#
import joblib
import pandas as pd
from textblob import TextBlob
import os
import logging
logger = logging.getLogger(__name__)
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
def split_into_tokens(message):
    #message = unicode(message, 'utf8')  # convert bytes into proper unicode
    return TextBlob(message).words
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
def split_into_lemmas(message):
    message = message.lower()
    words = TextBlob(message).words
    # for each word, take its "base form" = lemma 
    return [word.lemma for word in words]
#------------------------------------------------------------------------------#    

#------------------------------------------------------------------------------#
def outlier_detect(input_sentence):
    logger.info("In outlier_detect:loading out lier ML model....")
    weight_file = os.getcwd()+"/model_weight_files/outlier_detect_model.joblib"
    trained_model = joblib.load(weight_file)
    logger.info("Model loaded and Make it series")
    test_sample = pd.Series(input_sentence)
    logger.info("Predicting the outliers...")
    prection_output = trained_model.predict(test_sample).tolist()
    logger.info("End of outlier_detect")
    return prection_output
#------------------------------------------------------------------------------#
