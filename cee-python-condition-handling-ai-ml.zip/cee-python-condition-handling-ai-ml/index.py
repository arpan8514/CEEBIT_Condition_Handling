import logging
import sys,getopt
import uvicorn
from fastapi import FastAPI
from dotenv import load_dotenv
from api.apis import router
from util.util import split_into_lemmas,split_into_tokens
from pydentic_class.setting import Settings

import os
load_dotenv()
logging.config.fileConfig('logging.conf', disable_existing_loggers=False)
logger = logging.getLogger(__name__)  # the __name__ resolve to "main" since we are at the root of the project.
# This will get the root logger since no logger in the configuration has this name.

root_path = os.getenv('ROOT_PATH')
settings = Settings()
api = FastAPI(title="Cognitive Handling of CEEBIT Conditions",
              description="Cognitive Handling of CEEBIT Conditions",
              version="0.0.16",root_path=root_path)

"""def custom_openapi():
    with open("./swagger/openapi.json", "r") as openapi:
        return json.load(openapi)"""


def configure():
    api.include_router(router)
    # api.openapi = custom_openapi



configure()
if __name__ == "__main__":
    argv =sys.argv[1:]
    opt_dist = {argv[i]: argv[i+1] for i in range(0,len(argv),2) }
    host = opt_dist["--ip"]
    port = int(opt_dist["--port"])
    env = opt_dist["--env"]
    logger.setLevel(logging.DEBUG)
    uvicorn.run(api, host=host, port=port, debug=True)
