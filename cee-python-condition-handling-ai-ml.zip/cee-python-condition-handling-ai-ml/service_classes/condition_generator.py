import logging,os,re,json
import lexnlp.extract.en.conditions
import nltk
from nltk.corpus import brown
from util.outlier_predict import outlier_detect
from util.util import *

logger = logging.getLogger(__name__)


class ConditionGenerator():
    brown_train = brown.tagged_sents(categories='news')
    const_rules = ""
    const_words = ""
    regexp_tagger = ""
    cfg = {}
    unigram_tagger = ""
    bigram_tagger = ""
    main_topic_extractor_tags = ""
    condition_extractor_tags = ""
    MAIN_TOPIC = 'main_topic'
    CONDITION_TOPIC = 'condition_topic'
    cunck_subtree_name_list = None
    operator_keyword_dist = None
    def __init__(self):
        constant_folder_path = os.path.abspath(os.getenv("CONSTANT_FOLDER"))
        f_rules = open(constant_folder_path+'/rules.json')
        self.const_rules = json.load(f_rules)
        f_words = open(constant_folder_path + '/word_phrase.json')
        self.const_words = json.load(f_words)
        #NLTK backoff regular expression
        self.regexp_tagger =  nltk.RegexpTagger([(re.compile(rule),key) for key,rule in self.const_rules["backoff_nltk_regular_exp"].items()])
        # Grammar Definition
        for key, rule in self.const_rules["noun_phrase_grammer"].items():
            self.cfg[key] = rule
        self.unigram_tagger = nltk.UnigramTagger(self.brown_train, backoff=self.regexp_tagger )
        self.bigram_tagger = nltk.BigramTagger(self.brown_train, backoff=self.unigram_tagger)
        self.main_topic_extractor_tags = self.const_rules["topic_extractor_tags"]["main_topic"]
        self.condition_extractor_tags = self.const_rules["topic_extractor_tags"]["condition_extractor"]
        self.operator_chunck_key_words = self.const_rules['operator_chunck_key_words']





    def createConditionJson(self, condition_list):
        logger.info("Create condition json started")
        json_list = {}
        not_acceped_sentences = {}
        logger.info("Start process all sentences...")
        for key, input_sentence in condition_list.items():
            if len(input_sentence.strip(" ")) > 0:

                main_response = self.process_condition_statement(input_sentence)

                statement = main_response['extract_part_2']
                if (main_response['not_acceped_sentences'] != ""):
                    not_acceped_sentences[key] = main_response['not_acceped_sentences']
                temp_dict = {}
                if (statement):
                    temp_dict["action_statement"] = statement['action_extract']
                    temp_dict["condition_statement"] = statement['condition_extract']
                    temp_dict["logical_conditions"] = statement['query']
                    json_list[key] = temp_dict

        json_list["not_accepted_sentences"] = not_acceped_sentences
        logger.info("Create condition json End")
        return json_list

    # Normalize brown corpus' tags ("NN", "NN-PL", "NNS" > "NN")
    def normalize_tags(self, tagged):
        n_tagged = []
        for t in tagged:
            if t[1] == "NP-TL" or t[1] == "NP":
                n_tagged.append((t[0], "NNP"))
                continue
            if t[1].endswith("-TL"):
                n_tagged.append((t[0], t[1][:-3]))
                continue
            if t[1].endswith("S"):
                n_tagged.append((t[0], t[1][:-1]))
                continue
            n_tagged.append((t[0], t[1]))
        return n_tagged

    #####Create tags by pos tagging of NLTK####
    def createTagByPosTag(self, sentence):
        tokens = tokenize_sentence(sentence)
        tags = nltk.pos_tag(tokens)
        print("Normal pos Tag:",tags)
        return tags
    #####Create tree from sentence####
    def subTreeFromSentence(self,chunck_rule,sentence):
        cp = nltk.RegexpParser(chunck_rule)
        return cp.parse(self.createTagsForSentence(sentence))

    #####Create tags by bigrams####
    def createTagsForSentence(self, sentence):
        tokens = tokenize_sentence(sentence)
        tags = self.normalize_tags(self.bigram_tagger.tag(tokens))
        print("Bigram Tag:",tags)
        return tags

    #####Filter tags by Custom grammers####
    def filterTagsByGrammer(self, tags):
        logger.info("filterTagsByGrammer started...")
        merge = True
        c_index = -1
        index_before_c = []
        logger.info("Search for for 'C' tag")
        for i in range(0,len(tags)):
            if (tags[i][1] in self.const_rules["not_allowed_C_tags"]["tags"] and tags[i][0] in
                    self.const_rules["not_allowed_C_tags"]["words"]):
                c_index = i
                break
            elif(tags[i][1] in self.const_rules["not_allowed_before_C_tag"]):
                 index_before_c.append(i)

        if c_index>0:
            logger.info("'C' tag found, removing NN, AT befor C tag")
            for index in sorted(index_before_c, reverse=True):
                del tags[index]
        logger.info("Merging tags on basis of custom grammers")
        while merge:
            merge = False
            for x in range(0, len(tags) - 1):
                t1 = tags[x]
                t2 = tags[x + 1]
                key = "%s+%s" % (t1[1], t2[1])
                value = self.cfg.get(key, '')
                if value:
                    merge = True
                    tags.pop(x)
                    tags.pop(x)
                    match = "%s %s" % (t1[0], t2[0])
                    pos = value
                    tags.insert(x, (match, pos))
                    break

        logger.info("filterTagsByGrammer End...")
        return tags

        #####Get Synomims####

    def getSynonimList(self, type_list):
       return  self.const_words["action_synonims"]

    #####Extract ONLY NP from Sentence####
    def extract(self, topic_type, input_text):
        invalid_tags = self.const_rules["invalid_tags"]
        input_text = input_text.lower()
        tags = self.createTagsForSentence(input_text)
        is_invalid_tag_found = False
        for w in tags:
            if w[1] in invalid_tags:
                logger.info("Invalid tag found "+w[1])
                is_invalid_tag_found = True
                break
        if is_invalid_tag_found:
            logger.info("Using Pos tag for topic extraction")
            tags = self.createTagByPosTag(input_text)
        tags = self.filterTagsByGrammer(tags)
        topic_extractor = []
        if (topic_type == self.MAIN_TOPIC):
            topic_extractor = self.main_topic_extractor_tags
        elif (topic_type == self.CONDITION_TOPIC):
            topic_extractor = self.condition_extractor_tags
        matches = []
        matches_tags = []
        for t in tags:
            if (t[1] in topic_extractor):
                matches.append(t[0])
                matches_tags.append(t)
        print(tags)
        return {'tags': tags, 'matches': matches,'matches_tags':matches_tags}

    ######## Extracting Action - field_label ############
    def extractingAction(self, action, type_list_dist):
        logger.info('extractingAction started..')
        logger.info("Action sentece: "+action)
        type_of_condition = ''
        extracted_list = []
        action_2 = ''
        logger.info('Search for action word...')
        """for cond_type in type_list_dist:
            tfound = False
            for i in range(0, len(type_list_dist[cond_type])):
                word = r'\b' + type_list_dist[cond_type][i] + '\\b'
                # print(type_list_dist[cond_type][i])
                if (re.search(word, action.lower())):
                    tfound = True
                    action_2 = action.lower().replace(type_list_dist[cond_type][i], "").strip(" ")
                    type_of_condition = cond_type
                    break
            if (tfound): break"""
        type_of_condition,action_2, tfound= findActionWord(type_list_dist,action).values()
        if(tfound==False):
            action_stem_tokens = stemmingSentence(action)
            print("Lema sent:"+action)
            type_of_condition, action_2, tfound = findActionWordFromToken(type_list_dist, action,action_stem_tokens).values()
        logger.info('Extracting the noun-phrase')
        np_result_dist = self.extract(self.MAIN_TOPIC, action_2)
        np_result = np_result_dist['matches']
        print("np_result: ", np_result)
        # print (len(np_result))
        field_label = " ".join(np_result)
        # print ("field_label: [%s]" %field_label)
        extracted_list.append({"field_label": field_label})
        # print ("type_of_condition: [%s]" %type_of_condition)
        extracted_list.append({"type_of_condition": type_of_condition})
        logger.info('End of extractingAction')
        return extracted_list

    ######## Extracting Action - field_label and conditions ############
    def extractingCondition(self, condition_category,condition_json_list):
        logger.info('-------extractingCondition started--------')
        #logical_ops = [ele for ele in logical_conjunction if (ele in condition)]
        #logical_ops = logical_ops[0] if len(logical_ops) > 0 else ""
        condition = condition_category[0]
        sentence_category = condition_category[1]

        """noun_conjunction_check = "NN_CONJUN:{<NN><CC><NN><.*>+<CC>*}"
        noun_conjunction_check =noun_conjunction_check +"\n"+"}<CC>{"
        cs_nn = self.subTreeFromSentence(noun_conjunction_check, condition)
        print("SUB Tree:",cs_nn)
        cs_nn_elem = []
        for subtree in cs_nn.subtrees(filter=lambda t: t.label() == 'NN_CONJUN'):
            cs_nn_elem.append(" ".join([w[0] for w in subtree.leaves()]))
        #print("condition: ", cs_nn_elem)
        if(len(cs_nn_elem)>0):
            for i in range(0,len(cs_nn_elem),2):
                reform = cs_nn_elem[i]+" "+" ".join(cs_nn_elem[i+1].split(" ")[1:])
                condition = condition.replace(cs_nn_elem[i],reform)"""

        print("condition: ", condition)
        logger.info('Chunking and Chinking by conjunction')
        sentences = conjunctionSpliter(condition)

        split_by_to = False
        """logger.info('Checking for from and to key words in sentence...')
        if (len(sentences) == 1):
            if ('from' in condition and 'to' in condition):
                sentences = re.split(r"\bto\b", condition)
                sentences[1] = 'to ' + sentences[1]
                split_by_to = True"""
        print(sentences)
        condition_extract_list = []
        condition_tags = []
        comparison_extractor_chunk = "\n".join(self.const_rules['comparison_extractor_chunk'])
        cunck_subtree_name_list = [rule.split(":")[0] for rule in self.const_rules['comparison_extractor_chunk']]
        #print(cunck_subtree_name_list)
        len_cond_sent = len(sentences)
        i = 0
        from_to_split_done = False
        while i < len_cond_sent:
            each_condition_sentence = sentences[i].strip(" ")
            logger.info("Condition: "+ each_condition_sentence)
            logger.info('Category of condition: '+sentence_category)

            if(sentence_category == "cat_form_to" and not from_to_split_done):
               temp_sentences = re.split(r"\bto\b", each_condition_sentence,flags=re.IGNORECASE)
               temp_sentences[1] = 'to ' + temp_sentences[1]
               sentences[i] = temp_sentences[0]
               sentences.insert(i+1,temp_sentences[1])
               each_condition_sentence = sentences[i]
               from_to_split_done = True


            len_cond_sent = len(sentences)
            comparision_opt = ""
            temp_dict = {}
            logger.info('Taging and extracting noun-phrase from sentence and get conditions')
            np_result_dist = self.extract(self.CONDITION_TOPIC, each_condition_sentence)

            np_result = np_result_dist['matches']
            condition_tags.append(np_result_dist['tags'])
            print("Condition np_result: ", np_result)
            # print (len(np_result))
            field_label_condition = np_result[-1]
            # print("field_label_condition: ", field_label_condition)
            temp_dict["field_label_condition"] = field_label_condition

            comparison_val_tags = np_result_dist['matches_tags'][:-1]
            logger.info("Removing last preposition..")
            comparion_of_val = removeWordFromLast(comparison_val_tags,self.const_rules["last_not_allowed_tags"])
            logger.info("comparion_of_val:" + comparion_of_val)
            cond_id_count = len(condition_json_list)


            if (comparion_of_val == ''):
              if(sentence_category in ["cat_form_to","cat_between_and"]):
                comparion_of_val = condition_extract_list[i - 1]['comparion_of_val'] if i - 1 >= 0 else ""
                cond_id_count = cond_id_count + i
              else:
                  comparion_of_val = condition_json_list[len(condition_json_list) - 1]['comparion_of_val'] if len(
                      condition_json_list) - 1 >= 0 else ""

            cs = self.subTreeFromSentence(comparison_extractor_chunk,condition)
            print(cs)
            chunk_found = False
            sub_tree_list = []
            for sub_tree in cs.subtrees():
                if sub_tree.label() in cunck_subtree_name_list:
                    chunk_found = True
                    sub_tree_list.append(sub_tree)

            if (self.checkListOfWordInSentence("equeal",each_condition_sentence)):
                comparision_opt = self.operator_chunck_key_words["equeal"]["symbol"]
            if (self.checkListOfWordInSentence("greater_than_equal",each_condition_sentence)):
                comparision_opt = self.operator_chunck_key_words["greater_than_equal"]["symbol"]
            elif (self.checkListOfWordInSentence("greater_than",each_condition_sentence)):
                comparision_opt = self.operator_chunck_key_words["greater_than"]["symbol"]
            elif (self.checkListOfWordInSentence("less_than_equal",each_condition_sentence)):
                comparision_opt = self.operator_chunck_key_words["less_than_equal"]["symbol"]
            elif (self.checkListOfWordInSentence("less_than",each_condition_sentence)):
                comparision_opt = self.operator_chunck_key_words["less_than"]["symbol"]
            if ('length' in comparion_of_val):
                comparion_of_val = re.sub(r"\blength\b", '', comparion_of_val,re.IGNORECASE)
                comparion_of_val = comparion_of_val.strip(" ")
                comparion_of_val = 'lenght ' + comparion_of_val
            if (self.checkListOfWordInSentence("not_equeal",each_condition_sentence)):
                comparision_opt = self.operator_chunck_key_words["not_equeal"]["symbol"]+comparision_opt

            temp_dict["comparion_of_val"] = comparion_of_val

            if chunk_found:
                for el in sub_tree_list:
                    #print("el.label()",el.label() in self.operator_chunck_key_words["equeal"]["subtree"])
                    if (el.label() in self.operator_chunck_key_words["greater_than_equal"]["subtree"]) \
                            and self.checkListOfWordInSentence('greater_than_equal',each_condition_sentence,'subtree'):
                        comparision_opt = self.operator_chunck_key_words["greater_than_equal"]["symbol"]
                    elif (el.label() in self.operator_chunck_key_words["less_than_equal"]["subtree"]) \
                            and self.checkListOfWordInSentence("less_than_equal",each_condition_sentence,'subtree'):
                        comparision_opt = self.operator_chunck_key_words["less_than_equal"]["symbol"]
                    elif (el.label() in self.operator_chunck_key_words["less_than_equal"]["subtree"]) and \
                            (np_result_dist['tags'][0][1] in self.operator_chunck_key_words["less_than_equal"]["tags"]):
                        comparision_opt = self.operator_chunck_key_words["less_than_equal"]["symbol"]
                    elif (el.label() in self.operator_chunck_key_words["equeal"]["subtree"]):
                        match_word = getMatchWordFromList('equeal', each_condition_sentence,self.operator_chunck_key_words,'subtree')
                        if(match_word[0]):
                            op = [w[0] for w in el.leaves() if w[1] in self.operator_chunck_key_words["equeal"]["tags"]][0]
                            comparision_opt = self.operator_chunck_key_words["equeal"]["symbol"]
                            temp_dict['field_label_condition'] = op + " "+match_word[1]+" "+ temp_dict['field_label_condition']
                        if(el.label()=="CHUNK4"):
                            comparision_opt = self.operator_chunck_key_words["equeal"]["symbol"]
                            temp_v = temp_dict['field_label_condition']
                            temp_dict["comparion_of_val"] = temp_v
                            leaves = el.leaves()
                            temp_dict['field_label_condition'] = leaves[len(leaves)-1][0]


            if (comparision_opt == ''):
                logger.info("IOB Tagging")
                name = IOBTagging(condition)
                temp_dict['field_label_condition'] = name

                if(" ".join(tokenize_sentence(condition)).replace(temp_dict['field_label_condition'],"")==""):
                    logger.info("Single value in condition")
                    comparision_opt = condition_json_list[cond_id_count - 1]['comparion_operator'] if cond_id_count - 1 >= 0 else ""

            temp_dict["comparion_operator"] = comparision_opt
            temp_dict['id'] = 'cond' + str((cond_id_count+1))
            condition_extract_list.append(temp_dict)

            i=i+1
            # print("condition_extract_list: ", condition_extract_list)

        logger.info('End of extractingCondition')
        return {"condition_extract_list": condition_extract_list}

    ######## One inner controller to process conditions ############
    def process_condition_statement(self, input_text):
        logger.info("========process_condition_statement started========")
        not_acceped_sentences = ""
        action = ""
        temp_then =""
        logger.info("input_text: "+ input_text)
        logger.info('Split the sentence by conditional words -')
        input_text = input_text.strip(" ")
        cond_word_ser_output = stringSearchIgnoreCase(self.const_words["conditional_word"],input_text)
        re_output = cond_word_ser_output["re_output"]
        temp_cond_word = cond_word_ser_output["cond_word"]
        logger.info("Conditional word found: "+temp_cond_word)
        if(re_output and re_output.span()[0]>0):
            logger.info("Conditional word not in front of sentence")
            regx = r"\b"+temp_cond_word+"\\b"
            result = re.split(regx,input_text,flags=re.IGNORECASE)
            if (len(result) > 0):
                action = result[0]

        elif(re_output and re_output.span()[0]==0):
            re_output_then = re.search(r"\bthen\b", input_text, re.IGNORECASE)
            if(re_output_then and re_output_then.span()[0]>0):
                temp_result = re.split(r"\bthen\b",input_text, flags= re.IGNORECASE)
                if(len(temp_result)>0):
                    action = temp_result[1]
                    temp_then = "then"
            elif(input_text.find(",")>-1):
                action = input_text[input_text.find(",")+1:]

                temp_then = ","
        print("temp: ", temp_cond_word)
        print("action: ", action)
        logger.info('Extracting conditions...')
        extract_part_2 = {}
        ignorecase_temp = r"\b"+temp_cond_word+"\\b"
        ignorecase_then = r"\b"+temp_then+"\\b"
        condition = input_text.replace(action, "").lstrip(" ")
        print(re.sub(ignorecase_temp,"",condition,flags=re.IGNORECASE))
        condition = re.sub(ignorecase_temp,"",condition,flags=re.IGNORECASE).strip(" ")
        condition = re.sub(ignorecase_then,"",condition,flags=re.IGNORECASE).strip(" ")
        model_response = True
        logger.info("Scan by outlier ml model: " + condition)
        outlier_result = outlier_detect(condition)
        model_response = outlier_result[0] == 'accept'
        logger.info("Outlier model output: " + outlier_result[0])
        if (model_response==True):
            logger.info('Getting all synonims...')
            type_list_dist = self.getSynonimList([])

            ######## Extracting Action - field_label and type_of_condition ############
            logger.info('Extract action from sentence')
            action_extract_list = self.extractingAction(action, type_list_dist)
            extract_part_2["action_extract"] = action_extract_list
            extract_part_2["condition_extract"] = []
            ########## END OF Extracting Action ############

            ######## Extracting Condition  ############
            unexpected_conjuction_phrase = self.const_words["extra_conjunction_phrase"]
            logger.info('Removing unexpected conjunction...')
            condition = removeUnexpectedConjunction(condition,
                                                    unexpected_conjuction_phrase)  # remove or from 'like greater than or equals to'
            logger.info('Split the sentence into multiple unit conditional sentences...')
            splited_conditions = extractEachConditionSentence(condition)
            logger.info('Set the category for each conditional sentence')
            sentence_category_list = self.getCategoryOfsentence(splited_conditions)
            logger.info('Running loop for each condition and get json...')
            for each_condition in sentence_category_list:
                condition_extract_dist = self.extractingCondition(each_condition,extract_part_2["condition_extract"])
                ########## END OF Extracting Conditions ############

                #logical_op = " " + condition_extract_dist['logical_ops'] + " "

                extract_part_2["condition_extract"].extend(condition_extract_dist['condition_extract_list'])
                #extract_part_2["query"] = "(" + logical_op.upper().join(
                #    [cond['id'] for cond in extract_part_2["condition_extract"]]) + ")"
            logger.info('Find out the logical(conjunction) relation amongs condtional sentences')
            logical_conditions = createConditionStatement(self.const_rules['conjunction_phrase'], condition,
                                                          extract_part_2["condition_extract"])
            extract_part_2["query"] = logical_conditions
            logger.info('End of process_condition_statement')
        else:
            logger.info('Appned this sentence into non-accepted list')
            not_acceped_sentences = input_text
        return {"extract_part_2": extract_part_2, "not_acceped_sentences": not_acceped_sentences}


    def checkListOfWordInSentence(self,index, sentence,is_chunck=""):

        found = False
        key_index = 'keywords'
        if(is_chunck == "subtree"):
            key_index = 'subtree_keywords'

        for word in self.operator_chunck_key_words[index][key_index]:
            word_regx = r"\b"+word+"\\b"
            if (re.search(word_regx,sentence,re.IGNORECASE)):
            #if(word in sentence):
                found = True
                break
        return found

    def getCategoryOfsentence(self,sentences):
        sent_cat_dist = self.const_rules["sentence_category"]
        category_sentese = []
        for sentence in sentences:
            found_category = False
            if (findWordInSentence(['between'], sentence)):
                category_sentese.append((sentence, "cat_between_and"))
                found_category = True

            for cat,word_list in sent_cat_dist.items():
                if(found_category):
                    break
                elif(cat=="cat_form_to"):
                    if (findWordInSentence(['from'], sentence) and findWordInSentence(['to'], sentence)):
                        category_sentese.append((sentence,cat))
                        found_category = True
                        break
                else:
                    if (findWordInSentence(word_list, sentence)):
                        category_sentese.append((sentence, cat))
                        found_category = True
                        break
            if(found_category==False):
                category_sentese.append((sentence,"cat_default"))

        return category_sentese


