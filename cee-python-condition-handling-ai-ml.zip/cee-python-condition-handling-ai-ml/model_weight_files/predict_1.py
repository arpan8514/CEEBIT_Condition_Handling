#------------------------------------------------------------------------------#
import joblib
import pandas as pd
import numpy
from textblob import TextBlob
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
def split_into_tokens(message):
    #message = unicode(message, 'utf8')  # convert bytes into proper unicode
    return TextBlob(message).words
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
def split_into_lemmas(message):
    message = message.lower()
    words = TextBlob(message).words
    # for each word, take its "base form" = lemma 
    return [word.lemma for word in words]
#------------------------------------------------------------------------------#    

#------------------------------------------------------------------------------#
def check():
    weight_file = "outlier_detect_model.pkl"
    trained_model = joblib.load(weight_file)

    #input_sentence = "Display the address of the employee if first name of the employee starts with B."
    input_sentence = "Ramaull is a Taliban but he is a good person"

    test_sample = pd.Series(input_sentence)
    print (test_sample)

    prection_output = trained_model.predict(test_sample)
    print ("Prediction Result: ", prection_output)
#------------------------------------------------------------------------------#
if __name__ == '__main__':
    check()