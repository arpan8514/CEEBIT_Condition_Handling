from pydantic import BaseModel,Field
condition_responses = {
    400: {"description": "Error Message"},
    500:{"status":"Error","status_code":500,"description": "Error Message"},
    200:{"description":"Condition json",
         "content":{
                "application/json":{
                        "example": {
                            "status":"OK",
                            "status_code":200,
                            "condition_json":{
                                              "sentence1": {
                                                "action_statement": [
                                                  {
                                                    "field_label": "address line 1"
                                                  },
                                                  {
                                                    "type_of_condition": "display"
                                                  }
                                                ],
                                                "condition_statement": [
                                                  {
                                                    "field_label_condition": "10",
                                                    "comparion_of_val": "age",
                                                    "comparion_operator": "GTE",
                                                    "id": "cond1"
                                                  },
                                                  {
                                                    "field_label_condition": "50",
                                                    "comparion_of_val": "age",
                                                    "comparion_operator": "LTE",
                                                    "id": "cond2"
                                                  }
                                                ],
                                                "logical_conditions": "cond1 OR cond2"
                                              },
                                              "not_accepted_sentences": {
                                                "sentence2": "Display the address line 1 if number of potential carriers will increase and it will be risky to travel through public transport"
                                              }
                                            }
                        }
                 }
                }
         }

}

class ConditionInput(BaseModel):
    sentences:dict = Field("",
                           example={"sentence1":"Display the address line 1 if age is greater than or equal to 10 or less than or "
                                    "equal to 50.",
                                    "sentence2": "Display the address line 1 if number of potential carriers will increase and it will be risky to travel through public transport"
                                    })
class ConditionOutput(BaseModel):
    status:str = Field("Status",example="OK")
    status_code: int = Field("Status code", example=200)
    condition_json_list:list = Field("condition json list",example={
                                                                      "sentence1": {
                                                                        "action_statement": [
                                                                          {
                                                                            "field_label": "address line 1"
                                                                          },
                                                                          {
                                                                            "type_of_condition": "display"
                                                                          }
                                                                        ],
                                                                        "condition_statement": [
                                                                          {
                                                                            "field_label_condition": "10",
                                                                            "comparion_of_val": "age",
                                                                            "comparion_operator": "GTE",
                                                                            "id": "cond1"
                                                                          },
                                                                          {
                                                                            "field_label_condition": "50",
                                                                            "comparion_of_val": "age",
                                                                            "comparion_operator": "LTE",
                                                                            "id": "cond2"
                                                                          }
                                                                        ],
                                                                        "logical_conditions": "(cond1 OR cond2)"
                                                                      },
                                                                      "not_accepted_sentences": {
                                                                        "sentence2": "Display the address line 1 if number of potential carriers will increase and it will be risky to travel through public transport"
                                                                      }
                                                                    })