from pydantic import BaseSettings
import os
class Settings(BaseSettings):
    openapi_url = ''
    def __init__(self):
      root_path = os.getenv('ROOT_PATH','')
      super().__init__()
      self.openapi_url: str = root_path+"/openapi.json"